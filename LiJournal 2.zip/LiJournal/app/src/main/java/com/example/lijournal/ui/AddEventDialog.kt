package com.example.lijournal.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import com.example.lijournal.data.AutoEvent
import kotlin.math.roundToInt

object AddEventDialog {

    fun show(
        context: Context,
        type: String,
        defaultTitle: String,
        onSave: (AutoEvent) -> Unit
    ) {
        val pad = dp(context, 16)

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // --- Общие поля ---
        val titleEt = EditText(context).apply {
            hint = "Название"
            textSize = 32f
            setPadding(24, 24, 24, 24)
        }

        val odoEt = EditText(context).apply {
            hint = "Пробег (км)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("")
            textSize = 28f
            setPadding(24, 24, 24, 24)
        }

        container.addView(titleEt)
        container.addView(odoEt)

        if (type == "FUEL") {
            // --- FUEL UI (RadioButtons вместо Spinner) ---

            val modeLabel = TextView(context).apply {
                text = "Что записываем:"
                textSize = 26f
                setTextColor(Color.BLACK)
                setPadding(0, dp(context, 12), 0, dp(context, 6))
            }

            val radioGroup = RadioGroup(context).apply {
                orientation = RadioGroup.HORIZONTAL
                setPadding(0, 0, 0, dp(context, 8))
            }

            val rbGas = RadioButton(context).apply {
                text = "Бензин"
                textSize = 26f
                setPadding(dp(context, 8), dp(context, 8), dp(context, 16), dp(context, 8))
                isChecked = true
            }

            val rbElectric = RadioButton(context).apply {
                text = "Зарядка"
                textSize = 26f
                setPadding(dp(context, 8), dp(context, 8), dp(context, 16), dp(context, 8))
            }

            radioGroup.addView(rbGas)
            radioGroup.addView(rbElectric)

            val qtyEt = EditText(context).apply {
                hint = "Количество (л или кВт⋅ч)"
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setText("")
                textSize = 28f
                setPadding(24, 24, 24, 24)
            }

            val priceEt = EditText(context).apply {
                hint = "Цена за 1 (₽/л или ₽/кВт⋅ч)"
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setText("")
                textSize = 28f
                setPadding(24, 24, 24, 24)
            }

            val sumPreview = TextView(context).apply {
                text = "Сумма: 0 ₽"
                textSize = 32f
                gravity = Gravity.END
                setPadding(0, dp(context, 12), 0, 0)
                setTextColor(Color.BLACK)
            }

            var currentSum = 0
            var autoTitleEnabled = true

            titleEt.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) autoTitleEnabled = false
            }

            fun recalc() {
                val qty = qtyEt.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
                val price = priceEt.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
                val sum = (qty * price).roundToInt()
                currentSum = sum
                sumPreview.text = "Сумма: $sum ₽"

                if (autoTitleEnabled) {
                    val modeText = if (rbGas.isChecked) "Бензин" else "Зарядка"
                    val unit = if (rbGas.isChecked) "л" else "кВт⋅ч"
                    val autoTitle = "$modeText: $qty $unit × $price ₽ = $sum ₽"
                    titleEt.setText(autoTitle)
                    titleEt.setSelection(titleEt.text.length)
                }
            }

            val watcher = object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) { recalc() }
            }

            qtyEt.addTextChangedListener(watcher)
            priceEt.addTextChangedListener(watcher)
            radioGroup.setOnCheckedChangeListener { _, _ -> recalc() }

            container.addView(modeLabel)
            container.addView(radioGroup)
            container.addView(qtyEt)
            container.addView(priceEt)
            container.addView(sumPreview)

            val dialog = AlertDialog.Builder(context)
                .setTitle("Новая запись")
                .setView(container)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить") { _, _ ->
                    val title = titleEt.text.toString().ifBlank { defaultTitle }
                    val odometer = odoEt.text.toString().toIntOrNull() ?: 0

                    val fuelType = if (rbGas.isChecked) "FUEL_GAS" else "FUEL_ELECTRIC"

                    onSave(
                        AutoEvent(
                            type = fuelType,
                            title = title,
                            dateTimeMillis = System.currentTimeMillis(),
                            odometerKm = odometer,
                            partsCost = currentSum,
                            laborCost = 0
                        )
                    )
                }
                .create()

            dialog.show()
            enlargeDialogButtons(dialog)

        } else {
            // --- Обычный UI для других типов ---

            val partsEt = EditText(context).apply {
                hint = "Стоимость запчастей / материалов (₽)"
                inputType = InputType.TYPE_CLASS_NUMBER
                setText("")
                textSize = 28f
                setPadding(24, 24, 24, 24)
            }

            val laborEt = EditText(context).apply {
                hint = "Стоимость работ (₽)"
                inputType = InputType.TYPE_CLASS_NUMBER
                setText("")
                textSize = 28f
                setPadding(24, 24, 24, 24)
            }

            val detailsEt = EditText(context).apply {
                hint = if (type == "REPAIR")
                    "Что делали / какие работы (необязательно)"
                else
                    "Комментарий (необязательно)"
                setText("")
                textSize = 28f
                setPadding(24, 24, 24, 24)
            }

            val serviceNameEt = EditText(context).apply {
                hint = "Сервис (необязательно)"
                setText("")
                textSize = 28f
                setPadding(24, 24, 24, 24)
            }

            val masterNameEt = EditText(context).apply {
                hint = "Мастер (необязательно)"
                setText("")
                textSize = 28f
                setPadding(24, 24, 24, 24)
            }

            val locationEt = EditText(context).apply {
                hint = "Адрес/место (необязательно)"
                setText("")
                textSize = 28f
                setPadding(24, 24, 24, 24)
            }

            if (type == "SERVICE") {
                container.addView(serviceNameEt)
                container.addView(masterNameEt)
                container.addView(locationEt)
            }

            container.addView(partsEt)
            container.addView(laborEt)

            if (type == "REPAIR") {
                container.addView(detailsEt)
            }

            val dialog = AlertDialog.Builder(context)
                .setTitle("Новая запись")
                .setView(container)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить") { _, _ ->
                    val baseTitle = titleEt.text.toString().ifBlank { defaultTitle }
                    val odometer = odoEt.text.toString().toIntOrNull() ?: 0
                    val parts = partsEt.text.toString().toIntOrNull() ?: 0
                    val labor = laborEt.text.toString().toIntOrNull() ?: 0

                    val details = if (type == "REPAIR") detailsEt.text.toString().trim() else ""
                    val title = if (type == "REPAIR" && details.isNotBlank()) "$baseTitle — $details" else baseTitle

                    onSave(
                        AutoEvent(
                            type = type,
                            title = title,
                            dateTimeMillis = System.currentTimeMillis(),
                            odometerKm = odometer,
                            partsCost = parts,
                            laborCost = labor,
                            serviceName = if (type == "SERVICE") serviceNameEt.text.toString().trim().ifBlank { null } else null,
                            masterName  = if (type == "SERVICE") masterNameEt.text.toString().trim().ifBlank { null } else null,
                            location    = if (type == "SERVICE") locationEt.text.toString().trim().ifBlank { null } else null
                        )
                    )
                }
                .create()

            dialog.show()
            enlargeDialogButtons(dialog)
        }
    }

    private fun enlargeDialogButtons(dialog: AlertDialog) {
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply {
            textSize = 30f
            setPadding(80, 40, 80, 40)
        }
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply {
            textSize = 30f
            setPadding(80, 40, 80, 40)
        }
    }

    private fun dp(context: Context, dp: Int): Int =
        (dp * context.resources.displayMetrics.density).toInt()
}