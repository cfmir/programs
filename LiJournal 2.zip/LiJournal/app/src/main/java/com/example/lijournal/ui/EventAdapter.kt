package com.example.lijournal.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.lijournal.R
import com.example.lijournal.data.AutoEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EventAdapter(
    private val onLongClick: ((AutoEvent) -> Unit)? = null
) : ListAdapter<AutoEvent, EventAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_event, parent, false)
        return VH(v, onLongClick)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(getItem(position))
    }

    class VH(
        itemView: View,
        private val onLongClick: ((AutoEvent) -> Unit)?
    ) : RecyclerView.ViewHolder(itemView) {

        private val title: TextView = itemView.findViewById(R.id.tvTitle)
        private val meta: TextView = itemView.findViewById(R.id.tvMeta)
        private val cost: TextView = itemView.findViewById(R.id.tvCost)

        private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

        fun bind(e: AutoEvent) {
            title.text = e.title

            val date = dateFormat.format(Date(e.dateTimeMillis))

            val (icon, typeLabel) = when (e.type) {
                "FUEL_GAS" -> "⛽" to "Бензин"
                "FUEL_ELECTRIC" -> "🔌" to "Зарядка"
                "FUEL" -> "⛽" to "Топливо"
                "SERVICE" -> "🛠" to "ТО"
                "REPAIR" -> "🔧" to "Ремонт"
                else -> "📌" to e.type
            }

            val baseMeta = "$icon $typeLabel • $date • Пробег: ${e.odometerKm} км"

            val extras = if (e.type == "SERVICE") {
                listOfNotNull(
                    e.serviceName?.takeIf { it.isNotBlank() }?.let { "Сервис: $it" },
                    e.masterName?.takeIf { it.isNotBlank() }?.let { "Мастер: $it" },
                    e.location?.takeIf { it.isNotBlank() }?.let { "Место: $it" }
                ).joinToString(" • ").takeIf { it.isNotBlank() }
            } else null

            meta.text = if (extras != null) "$baseMeta • $extras" else baseMeta

            val costSum = e.partsCost + e.laborCost
            cost.text = "$costSum ₽"

            val colorRes = when (e.type) {
                "FUEL", "FUEL_GAS", "FUEL_ELECTRIC" -> R.color.cost_fuel
                "SERVICE" -> R.color.cost_service
                "REPAIR" -> R.color.cost_repair
                else -> R.color.cost_default
            }
            cost.setTextColor(ContextCompat.getColor(itemView.context, colorRes))

            itemView.setOnLongClickListener {
                onLongClick?.invoke(e)
                true
            }
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<AutoEvent>() {
            override fun areItemsTheSame(oldItem: AutoEvent, newItem: AutoEvent): Boolean =
                oldItem.id == newItem.id

            override fun areContentsTheSame(oldItem: AutoEvent, newItem: AutoEvent): Boolean =
                oldItem == newItem
        }
    }
}