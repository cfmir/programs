package com.example.lijournal.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Delete

@Dao
interface EventDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: AutoEvent)

    @Query("SELECT * FROM auto_events ORDER BY dateTimeMillis DESC")
    suspend fun getAll(): List<AutoEvent>

    @Query("SELECT COALESCE(SUM(partsCost + laborCost), 0) FROM auto_events")
    suspend fun getTotalCost(): Int

    @Delete
    suspend fun delete(event: AutoEvent)

    @Query("DELETE FROM auto_events WHERE id = :id")
    suspend fun deleteById(id: Long)
}
