package com.example.lijournal.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "auto_events")
data class AutoEvent(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val type: String,          // FUEL, SERVICE, REPAIR, ACCESSORY
    val title: String,         // Человеческое название
    val dateTimeMillis: Long,  // Когда

    val odometerKm: Int,       // Пробег

    val partsCost: Int,        // Запчасти / расходники
    val laborCost: Int,        // Работа

    val serviceName: String? = null,
    val masterName: String? = null,
    val location: String? = null,
)