package com.example.lijournal

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.lijournal.data.AppDatabase
import com.example.lijournal.data.EventDao
import com.example.lijournal.ui.AddEventDialog
import com.example.lijournal.ui.EventAdapter
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.graphics.Color
import java.util.Calendar
import android.net.Uri
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
import android.widget.LinearLayout
import android.view.Gravity
import android.view.ViewGroup






class MainActivity : AppCompatActivity() {

    private lateinit var totalCostText: TextView
    private lateinit var adapter: EventAdapter
    private lateinit var dao: EventDao
    private enum class PeriodFilter { MONTH, PREV_MONTH, YEAR, ALL }
    private var currentFilter: PeriodFilter = PeriodFilter.MONTH

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        totalCostText = findViewById(R.id.totalCostText)

        val recycler = findViewById<RecyclerView>(R.id.eventsRecycler)
        adapter = EventAdapter { event ->
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Удалить запись?")
                .setMessage(event.title)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Удалить") { _, _ ->
                    lifecycleScope.launch {
                        dao.deleteById(event.id)
                        updateUi()
                    }
                }
                .show()
        }

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val db = AppDatabase.getInstance(this)
        dao = db.eventDao()

        lifecycleScope.launch { updateUi() }

        findViewById<Button>(R.id.btnAbout).setOnClickListener {
            findViewById<Button>(R.id.btnAbout).setOnLongClickListener {
                lifecycleScope.launch {
                    cloneFewEventsToLastYear(3)
                    updateUi()
                }
                true
            }
            val aboutText = TextView(this).apply {
                text =
                    "LiJournal — личный журнал расходов и событий автомобиля.\n\n" +
                            "Автор: Кайгородцев Василий Алексеевич.\n" +
                            "Программа распоространяется бесплатно. Если вам нужна печатная реклама — заходите на сайт:\nwww.cfmir.ru\ncfmir@icloud.com\n\n" +
                            "© ${java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)}"

                setTextColor(Color.BLACK)
                textSize = 24f              // 🔥 ВОТ ЗДЕСЬ МЕНЯЕШЬ РАЗМЕР
                setPadding(40, 30, 40, 30)
                setLineSpacing(8f, 1.2f)    // читабельность
            }
            val qrImage = ImageView(this).apply {
                setImageResource(R.drawable.about_qr)

                layoutParams = LinearLayout.LayoutParams(
                    500, // ширина в px
                    500  // высота в px
                ).apply {
                    topMargin = 24
                }

                scaleType = ImageView.ScaleType.FIT_CENTER

                setOnClickListener {
                    startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://www.cfmir.ru")
                        )
                    )
                }
            }
            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                gravity = Gravity.CENTER_HORIZONTAL
                addView(aboutText)
                addView(qrImage)
            }

            AlertDialog.Builder(this)
                .setTitle("О программе")
                .setView(content)   // ← ВАЖНО
                .setPositiveButton("Ок", null)
                .show()
        }

        findViewById<Button>(R.id.btnFuel).setOnClickListener {
            AddEventDialog.show(
                context = this,
                type = "FUEL",
                defaultTitle = "Зарядка / Бензин"
            )
            { event ->
                lifecycleScope.launch {
                    dao.insert(event)
                    updateUi()
                }
            }
        }

        findViewById<Button>(R.id.btnService).setOnClickListener {
            AddEventDialog.show(
                context = this,
                type = "SERVICE",
                defaultTitle = "ТО"
            ) { event ->
                lifecycleScope.launch {
                    dao.insert(event)
                    updateUi()
                }
            }
        }

        findViewById<Button>(R.id.btnRepair).setOnClickListener {
            AddEventDialog.show(
                context = this,
                type = "REPAIR",
                defaultTitle = "Ремонт"
            ) { event ->
                lifecycleScope.launch {
                    dao.insert(event)
                    updateUi()
                }
            }
        }
        findViewById<Button>(R.id.btnFilterMonth).setOnClickListener {
            currentFilter = PeriodFilter.MONTH
            lifecycleScope.launch { updateUi() }
        }

        findViewById<Button>(R.id.btnFilterPrevMonth).setOnClickListener {
            currentFilter = PeriodFilter.PREV_MONTH
            lifecycleScope.launch { updateUi() }
        }

        findViewById<Button>(R.id.btnFilterYear).setOnClickListener {
            currentFilter = PeriodFilter.YEAR
            lifecycleScope.launch { updateUi() }
        }
        findViewById<Button>(R.id.btnFilterAll).setOnClickListener {
            currentFilter = PeriodFilter.ALL
            lifecycleScope.launch { updateUi() }
        }
        // Экспорт CSV + Share
        findViewById<Button>(R.id.btnExport).setOnClickListener {
            lifecycleScope.launch {
                exportCsvAndShare()
            }
        }
    }

    private suspend fun updateUi() {
        val allEvents = withContext(Dispatchers.IO) { dao.getAll() }

        val filtered = applyFilter(allEvents, currentFilter)

        val total = filtered.sumOf { it.partsCost + it.laborCost }

        totalCostText.text = "Всего затрат: $total ₽"
        adapter.submitList(filtered)
    }
    private fun applyFilter(
        events: List<com.example.lijournal.data.AutoEvent>,
        filter: PeriodFilter
    ): List<com.example.lijournal.data.AutoEvent> {

        if (filter == PeriodFilter.ALL) return events

        val cal = Calendar.getInstance()

        // начало текущего месяца
        fun startOfMonth(year: Int, month: Int): Long {
            val c = Calendar.getInstance()
            c.set(Calendar.YEAR, year)
            c.set(Calendar.MONTH, month)
            c.set(Calendar.DAY_OF_MONTH, 1)
            c.set(Calendar.HOUR_OF_DAY, 0)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            return c.timeInMillis
        }

        // начало следующего месяца
        fun startOfNextMonth(year: Int, month: Int): Long {
            val c = Calendar.getInstance()
            c.set(Calendar.YEAR, year)
            c.set(Calendar.MONTH, month)
            c.set(Calendar.DAY_OF_MONTH, 1)
            c.set(Calendar.HOUR_OF_DAY, 0)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            c.add(Calendar.MONTH, 1)
            return c.timeInMillis
        }

        val (from, to) = when (filter) {
            PeriodFilter.MONTH -> {
                val y = cal.get(Calendar.YEAR)
                val m = cal.get(Calendar.MONTH)
                startOfMonth(y, m) to startOfNextMonth(y, m)
            }
            PeriodFilter.PREV_MONTH -> {
                cal.add(Calendar.MONTH, -1)
                val y = cal.get(Calendar.YEAR)
                val m = cal.get(Calendar.MONTH)
                startOfMonth(y, m) to startOfNextMonth(y, m)
            }
            PeriodFilter.YEAR -> {
                val c1 = Calendar.getInstance()
                c1.set(Calendar.MONTH, Calendar.JANUARY)
                c1.set(Calendar.DAY_OF_MONTH, 1)
                c1.set(Calendar.HOUR_OF_DAY, 0)
                c1.set(Calendar.MINUTE, 0)
                c1.set(Calendar.SECOND, 0)
                c1.set(Calendar.MILLISECOND, 0)

                val c2 = Calendar.getInstance()
                c2.set(Calendar.MONTH, Calendar.JANUARY)
                c2.set(Calendar.DAY_OF_MONTH, 1)
                c2.set(Calendar.HOUR_OF_DAY, 0)
                c2.set(Calendar.MINUTE, 0)
                c2.set(Calendar.SECOND, 0)
                c2.set(Calendar.MILLISECOND, 0)
                c2.add(Calendar.YEAR, 1)

                c1.timeInMillis to c2.timeInMillis
            }
            else -> return events
        }

        return events.filter { it.dateTimeMillis in from until to }
    }

    private suspend fun cloneFewEventsToLastYear(count: Int = 3) = withContext(Dispatchers.IO) {
        val all = dao.getAll()
        if (all.isEmpty()) return@withContext

        val take = all.take(count)

        val cal = Calendar.getInstance().apply {
            add(Calendar.YEAR, -1)
            set(Calendar.HOUR_OF_DAY, 12)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        take.forEachIndexed { index, e ->
            cal.set(Calendar.MONTH, Calendar.JUNE)
            cal.set(Calendar.DAY_OF_MONTH, 10 + index)
            val newTime = cal.timeInMillis

            // ВАЖНО: id должен быть 0 (или null, если у тебя так) чтобы Room создал новую запись
            dao.insert(
                e.copy(
                    id = 0,
                    dateTimeMillis = newTime,
                    title = "ТЕСТ-КОПИЯ: ${e.title}"
                )
            )
        }
    }

    private suspend fun exportCsvAndShare() {
        val uri = withContext(Dispatchers.IO) {
            val events = dao.getAll()

            val df = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
            val dtf = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
            val fileDf = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.getDefault())
            val fileName = "li_journal_${fileDf.format(Date())}.csv"
            val sep = ';'

            fun esc(v: String?): String {
                val s = (v ?: "").replace("\"", "\"\"")
                return "\"$s\""
            }

            fun typeLabel(type: String): String = when (type) {
                "FUEL_GAS" -> "Бензин"
                "FUEL_ELECTRIC" -> "Зарядка"
                "FUEL" -> "Топливо"
                "SERVICE" -> "ТО"
                "REPAIR" -> "Ремонт"
                else -> type
            }

            val totalParts = events.sumOf { it.partsCost }
            val totalLabor = events.sumOf { it.laborCost }
            val grandTotal = totalParts + totalLabor

            val minOdo = events.map { it.odometerKm }.minOrNull()
            val maxOdo = events.map { it.odometerKm }.maxOrNull()
            val odoDelta = if (minOdo != null && maxOdo != null && maxOdo >= minOdo) maxOdo - minOdo else null

            val costPerKm = if (odoDelta != null && odoDelta > 0) {
                grandTotal.toDouble() / odoDelta.toDouble()
            } else null

            val byType = events.groupBy { typeLabel(it.type) }
                .mapValues { (_, list) -> list.sumOf { it.partsCost + it.laborCost } }
                .toList()
                .sortedByDescending { it.second }

            val sb = StringBuilder()
            sb.append('\uFEFF') // BOM для Excel

            val monthFmt = SimpleDateFormat("yyyy-MM", Locale.getDefault())
            val byMonth = events
                .groupBy { monthFmt.format(Date(it.dateTimeMillis)) }
                .toList()
                .sortedBy { it.first }
                .map { (m, list) ->
                    val parts = list.sumOf { it.partsCost }
                    val labor = list.sumOf { it.laborCost }
                    val total = parts + labor
                    Triple(m, parts, labor) to Pair(total, list.size)
                }

            // Сводка
            sb.append(esc("СВОДКА")).append('\n')
            sb.append(esc("Дата экспорта")).append(sep).append(esc(dtf.format(Date()))).append('\n')
            sb.append(esc("Количество записей")).append(sep).append(events.size).append('\n')
            sb.append(esc("Итого запчасти (₽)")).append(sep).append(totalParts).append('\n')
            sb.append(esc("Итого работы (₽)")).append(sep).append(totalLabor).append('\n')
            sb.append(esc("Итого общая сумма (₽)")).append(sep).append(grandTotal).append('\n')

            if (odoDelta != null) {
                sb.append(esc("Пробег: мин (км)")).append(sep).append(minOdo ?: "").append('\n')
                sb.append(esc("Пробег: макс (км)")).append(sep).append(maxOdo ?: "").append('\n')
                sb.append(esc("Пробег: разница (км)")).append(sep).append(odoDelta).append('\n')
            } else {
                sb.append(esc("Пробег: разница (км)")).append(sep).append(esc("недостаточно данных")).append('\n')
            }

            if (costPerKm != null) {
                sb.append(esc("Цена 1 км (₽/км)")).append(sep)
                    .append(String.format(Locale.US, "%.2f", costPerKm)).append('\n')
            } else {
                sb.append(esc("Цена 1 км (₽/км)")).append(sep).append(esc("недостаточно данных")).append('\n')
            }

            sb.append('\n')
            sb.append(esc("СУММА ПО ТИПАМ")).append('\n')
            sb.append(esc("Тип")).append(sep).append(esc("Сумма (₽)")).append('\n')
            for ((t, sum) in byType) sb.append(esc(t)).append(sep).append(sum).append('\n')

            sb.append('\n')
            sb.append(esc("СВОДКА ПО МЕСЯЦАМ")).append('\n')
            sb.append(esc("Месяц")).append(sep)
            sb.append(esc("Запчасти (₽)")).append(sep)
            sb.append(esc("Работы (₽)")).append(sep)
            sb.append(esc("Итого (₽)")).append(sep)
            sb.append(esc("Кол-во записей")).append('\n')

            for ((triple, pair) in byMonth) {
                val (m, parts, labor) = triple
                val (total, count) = pair
                sb.append(esc(m)).append(sep)
                sb.append(parts).append(sep)
                sb.append(labor).append(sep)
                sb.append(total).append(sep)
                sb.append(count).append('\n')
            }

            sb.append('\n')
            sb.append(esc("ТАБЛИЦА")).append('\n')
            sb.append("Дата").append(sep)
            sb.append("Тип").append(sep)
            sb.append("Название").append(sep)
            sb.append("Пробег (км)").append(sep)
            sb.append("Запчасти (₽)").append(sep)
            sb.append("Работы (₽)").append(sep)
            sb.append("Итого (₽)").append(sep)
            sb.append("Сервис").append(sep)
            sb.append("Мастер").append(sep)
            sb.append("Место").append(sep)
            sb.append("ID").append('\n')

            for (e in events) {
                val dateStr = df.format(Date(e.dateTimeMillis))
                val parts = e.partsCost
                val labor = e.laborCost
                val total = parts + labor

                sb.append(esc(dateStr)).append(sep)
                sb.append(esc(typeLabel(e.type))).append(sep)
                sb.append(esc(e.title)).append(sep)
                sb.append(e.odometerKm).append(sep)
                sb.append(parts).append(sep)
                sb.append(labor).append(sep)
                sb.append(total).append(sep)
                sb.append(esc(e.serviceName)).append(sep)
                sb.append(esc(e.masterName)).append(sep)
                sb.append(esc(e.location)).append(sep)
                sb.append(e.id).append('\n')
            }

            val file = File(cacheDir, fileName)
            file.writeText(sb.toString(), Charsets.UTF_8)

            FileProvider.getUriForFile(
                this@MainActivity,
                "${packageName}.fileprovider",
                file
            )
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Li Journal — экспорт CSV")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        startActivity(Intent.createChooser(intent, "Поделиться CSV"))
    }


}
